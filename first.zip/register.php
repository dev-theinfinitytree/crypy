
<?php
include 'core/login_core.php';
if(isset($_POST['p_name']) && isset($_POST['p_uname']) &&  isset($_POST['p_college']) && isset($_POST['p_pw'])){
    if(!empty($_POST['p_name']) && !empty($_POST['p_uname']) && !empty($_POST['p_pw'])){

        $name =$_POST['p_name'];
        $uname=$_POST['p_uname'];
        $pw=$_POST['p_pw'];
        $college=$_POST['p_college'];

        $lc=new login_core();
        $lc->register($name,$college,$uname,$pw);

        if($lc==true){

            header("Location: login.php?value=success"); /* Redirect browser */
            exit();
        }
        else{
            header("Location: register.php?value=unsuccess"); /* Redirect browser */
            exit();

        }


    }

}
?>
<head>
<script type="text/javascript">

    if (screen.width <= 699) {
        document.location = "register-mobile.php";
    }




</script>

<style>
    @import "http://fonts.googleapis.com/css?family=Ubuntu:400,700italic";
    @import "http://fonts.googleapis.com/css?family=Cabin:400";
    * {
        box-sizing: border-box;
    }

    html {
        background: #000;
        background-size: cover;
        font-size: 10px;
        height: 100%;
        overflow: hidden;
        position: absolute;
        text-align: center;
        width: 100%;
    }

    /* =========================================
    Stark Industries Logo
    ========================================= */
    #logo {
        animation: logo-entry 4s ease-in;
        width: 500px;
        margin: 0 auto;
        position: relative;
        z-index: 40;
    }

    h1 {
        animation: text-glow 2s ease-out infinite alternate;
        font-family: 'Ubuntu', sans-serif;
        color: #00a4a2;
        font-size: 48px;
        font-size: 4.8rem;
        font-weight: bold;
        position: absolute;
        text-shadow: 0 0 10px #000, 0 0 20px #000, 0 0 30px #000, 0 0 40px #000, 0 0 50px #000, 0 0 60px #000, 0 0 70px #000;
        top: 50px;
    }
    h1:before {
        animation: before-glow 2s ease-out infinite alternate;
        border-left: 535px solid transparent;
        border-bottom: 10px solid #00a4a2;
        content: ' ';
        height: 0;
        position: absolute;
        right: -74px;
        top: -10px;
        width: 0;
    }
    h1:after {
        animation: after-glow 2s ease-out infinite alternate;
        border-left: 100px solid transparent;
        border-top: 16px solid #00a4a2;
        content: ' ';
        height: 0;
        position: absolute;
        right: -85px;
        top: 24px;
        transform: rotate(-47deg);
        width: 0;
    }

    /* =========================================
    Log in form
    ========================================= */
    #fade-box {
        animation: input-entry 3s ease-in;
        z-index: 4;
    }

    .stark-login form {
        animation: form-entry 3s ease-in-out;
        background: #111;
        background: linear-gradient(#004746, #111111);
        border: 6px solid #00a4a2;
        box-shadow: 0 0 15px #00fffd;
        border-radius: 5px;
        display: inline-block;
        height: 350px;
        margin: 200px auto 0;
        position: relative;
        z-index: 4;
        width: 500px;
        transition: 1s all;
    }
    .stark-login form:hover {
        border: 6px solid #00fffd;
        box-shadow: 0 0 25px #00fffd;
        transition: 1s all;
    }
    .stark-login input {
        background: #222;
        background: linear-gradient(#333333, #222222);
        border: 1px solid #444;
        border-radius: 5px;
        box-shadow: 0 2px 0 #000;
        color: #888;
        display: block;
        font-family: 'Cabin', helvetica, arial, sans-serif;
        font-size: 13px;
        font-size: 1.3rem;
        height: 40px;
        margin: 20px auto 10px;
        padding: 0 10px;
        text-shadow: 0 -1px 0 #000;
        width: 400px;
    }
    .stark-login input:focus {
        animation: box-glow 1s ease-out infinite alternate;
        background: #0B4252;
        background: linear-gradient(#333933, #222922);
        border-color: #00fffc;
        box-shadow: 0 0 5px rgba(0, 255, 253, 0.2), inset 0 0 5px rgba(0, 255, 253, 0.1), 0 2px 0 #000;
        color: #efe;
        outline: none;
    }
    .stark-login input:invalid {
        border: 2px solid red;
        box-shadow: 0 0 5px rgba(255, 0, 0, 0.2), inset 0 0 5px rgba(255, 0, 0, 0.1), 0 2px 0 #000;
    }
    .stark-login button {
        animation: input-entry 3s ease-in;
        background: #222;
        background: linear-gradient(#333333, #222222);
        box-sizing: content-box;
        border: 1px solid #444;
        border-left-color: #000;
        border-radius: 5px;
        box-shadow: 0 2px 0 #000;
        color: #fff;
        display: block;
        font-family: 'Cabin', helvetica, arial, sans-serif;
        font-size: 13px;
        font-weight: 400;
        height: 40px;
        line-height: 40px;
        margin: 20px auto;
        padding: 0;
        position: relative;
        text-shadow: 0 -1px 0 #000;
        width: 400px;
        transition: 1s all;
    }
    .stark-login button:hover,
    .stark-login button:focus {
        background: #0C6125;
        background: linear-gradient(#393939, #292929);
        color: #00fffc;
        outline: none;
        transition: 1s all;
    }
    .stark-login button:active {
        background: #292929;
        background: linear-gradient(#393939, #292929);
        box-shadow: 0 1px 0 #000, inset 1px 0 1px #222;
        top: 1px;
    }

    /* =========================================
    Spinner
    ========================================= */
    #circle1 {
        animation: circle1 4s linear infinite, circle-entry 6s ease-in-out;
        background: #000;
        border-radius: 50%;
        border: 10px solid #00a4a2;
        box-shadow: 0 0 0 2px black, 0 0 0 6px #00fffc;
        height: 700px;
        width: 700px;
        position: absolute;
        top: 20px;
        left: 42.5%;
        margin-left: -250px;
        overflow: hidden;
        opacity: 0.4;
        z-index: -3;
    }

    #inner-cirlce1 {
        background: #000;
        border-radius: 50%;
        border: 36px solid #00fffc;
        height: 650px;
        width: 650px;
        margin: 10px;
    }
    #inner-cirlce1:before {
        content: ' ';
        width: 240px;
        height: 480px;
        background: #000;
        position: absolute;
        top: 0;
        left: 0;
    }
    #inner-cirlce1:after {
        content: ' ';
        width: 480px;
        height: 240px;
        background: #000;
        position: absolute;
        top: 0;
        left: 0;
    }

    /* =========================================
    Hexagon Mesh
    ========================================= */
    .hexagons {
        animation: logo-entry 4s ease-in;
        color: #000;
        font-size: 52px;
        font-size: 5.1rem;
        letter-spacing: -0.2em;
        line-height: 0.7;
        position: absolute;
        text-shadow: 0 0 6px #00fffc;
        top: 450px;
        width: 100%;
        transform: perspective(600px) rotateX(60deg) scale(1.4);
        z-index: -3;
    }

    /* =========================================
    Animation Keyframes
    ========================================= */
    @keyframes logo-entry {
        0% {
            opacity: 0;
        }
        80% {
            opacity: 0;
        }
        100% {
            opacity: 1;
        }
    }
    @keyframes circle-entry {
        0% {
            opacity: 0;
        }
        20% {
            opacity: 0;
        }
        100% {
            opacity: 0.4;
        }
    }
    @keyframes input-entry {
        0% {
            opacity: 0;
        }
        90% {
            opacity: 0;
        }
        100% {
            opacity: 1;
        }
    }
    @keyframes form-entry {
        0% {
            height: 0;
            width: 0;
            opacity: 0;
            padding: 0;
        }
        20% {
            height: 0;
            border: 1px solid #00a4a2;
            width: 0;
            opacity: 0;
            padding: 0;
        }
        40% {
            width: 0;
            height: 220px;
            border: 6px solid #00a4a2;
            opacity: 1;
            padding: 0;
        }
        100% {
            height: 220px;
            width: 500px;
        }
    }
    @keyframes box-glow {
        0% {
            border-color: #00b8b6;
            box-shadow: 0 0 5px rgba(0, 255, 253, 0.2), inset 0 0 5px rgba(0, 255, 253, 0.1), 0 2px 0 #000;
        }
        100% {
            border-color: #00fffc;
            box-shadow: 0 0 20px rgba(0, 255, 253, 0.6), inset 0 0 10px rgba(0, 255, 253, 0.4), 0 2px 0 #000;
        }
    }
    @keyframes text-glow {
        0% {
            color: #00a4a2;
            text-shadow: 0 0 10px #000, 0 0 20px #000, 0 0 30px #000, 0 0 40px #000, 0 0 50px #000, 0 0 60px #000, 0 0 70px #000;
        }
        100% {
            color: #00fffc;
            text-shadow: 0 0 20px rgba(0, 255, 253, 0.6), 0 0 10px rgba(0, 255, 253, 0.4), 0 2px 0 #000;
        }
    }
    @keyframes before-glow {
        0% {
            border-bottom: 10px solid #00a4a2;
        }
        100% {
            border-bottom: 10px solid #00fffc;
        }
    }
    @keyframes after-glow {
        0% {
            border-top: 16px solid #00a4a2;
        }
        100% {
            border-top: 16px solid #00fffc;
        }
    }
    @keyframes circle1 {
        0% {
            -moz-transform: rotate(0deg);
            -ms-transform: rotate(0deg);
            -webkit-transform: rotate(0deg);
            transform: rotate(0deg);
        }
        100% {
            -moz-transform: rotate(360deg);
            -ms-transform: rotate(360deg);
            -webkit-transform: rotate(360deg);
            transform: rotate(360deg);
        }
    }

</style>
    <script src="assets/js/gen_validatorv4.js" type="text/javascript"></script>
    </head>
<body>
<div id="logo">
    <h1><i> CRYPTHUNTER REGISTER</i></h1>
</div>
<section class="stark-login">

    <form action="" method="post" id="register" name="register">
        <div id="fade-box">
            <input  type="text" name="p_name" id="name" placeholder="Player Name" required>
            <input type="text" name="p_college" id="college" placeholder="College Name">
            <input type="text" name="p_uname" id="username" placeholder="User Email" required>
            <input type="password" name="p_pw" id="password" placeholder="Password" required>

            <button type="submit">Register</button>
        </div>
    </form>
    <script type="text/javascript">
        var frmvalidator  = new Validator("register");
        frmvalidator.addValidation("p_uname","email", "Enter a valid Email");
        frmvalidator.addValidation("p_pw","minlen=8", "Minimum Password length must be 8");
        frmvalidator.addValidation("p_pw","alnum", "Password can contain only alphanumeric charectar");
    </script>
    <div class="hexagons">
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <br>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <br>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>

        <br>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <br>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
        <span>&#x2B22;</span>
    </div>
</section>

<div id="circle1">
    <div id="inner-cirlce1">
        <h2> </h2>
    </div>
</div>



<ul>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
    <li></li>
</ul>
<script>
    check_form(){
        var a, b,c;
        // var x=val.search("*");
        var str = document.getElementById('password').value;
        var str2 = document.getElementById('username').value;
        if(/^[a-zA-Z0-9- ]*$/.test(str) == false) {
            alert('Your password is invalid.');
        }
        else if(str.length<8){
            alert('length of the password must be greater than 8');
        }
        else{
            a=1;
        }

        if(str2.length<5){
            alert('Your username must be 5 charectar long');
        }
        else{
            b=1;
        }


    }
</script>
<?php
if(isset($_GET['value'])){
    if($_GET['value']=="unsuccess"){
        ?>
        <p style="color:yellow; margin-left: 32%; font-size: 35px; position: absolute; top: 90%;"> Registration Unsuccessful. Try again!</p>
    <?php
    }
}
?>
</body>


